PORTOFOLIO HTML & CSS

Isi folder:
- index.html : struktur halaman portofolio
- style.css  : desain dan tampilan responsif

Cara menjalankan:
1. Ekstrak file ZIP.
2. Buka foldernya di Visual Studio Code.
3. Buka index.html.
4. Klik kanan lalu pilih "Open with Live Server" (jika ekstensi Live Server sudah terpasang), atau buka index.html langsung melalui browser.

Yang perlu kamu ubah:
- Nama, deskripsi diri, dan informasi sekolah jika diperlukan di index.html.
- Email dan username Instagram pada bagian Kontak.
- Bagian proyek agar sesuai dengan karya yang benar-benar kamu buat.

Website ini menggunakan HTML dan CSS saja, tanpa JavaScript.
